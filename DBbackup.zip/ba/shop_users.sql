INSERT INTO shop.users (customer_id, email, password, phone_number, username) VALUES (1, 'user1@gmail.com', '123', '343434', 'user1');
INSERT INTO shop.users (customer_id, email, password, phone_number, username) VALUES (2, 'geo@geo.com', 'geo', '3239425222', 'George Samaan');
