INSERT INTO shop.shopping_cart (id, date_added, is_active, customer_id) VALUES (1, '2022-06-28', true, 2);
