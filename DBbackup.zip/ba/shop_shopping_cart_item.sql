INSERT INTO shop.shopping_cart_item (id, quantity, product_id, shopping_cart_id) VALUES (1, 3, 1, 1);
INSERT INTO shop.shopping_cart_item (id, quantity, product_id, shopping_cart_id) VALUES (2, 1, 4, 1);
INSERT INTO shop.shopping_cart_item (id, quantity, product_id, shopping_cart_id) VALUES (3, 3, 6, 1);
